
--For each property in question a), return the following:

--Using rental payment amount, rental payment frequency, tenant start date and tenant end date to 
--write a query that returns the sum of all payments from start date to end date. 

SELECT P.Id AS [PropertyId], P.Name AS [PropertyName], OP.OwnerId, TP.StartDate, TP.EndDate, TP.PaymentAmount, TPF.Name AS [PaymentFrequency],

CASE
WHEN TP.PaymentFrequencyId=1 THEN (DATEDIFF(WEEK, TP.StartDate, TP.EndDate)*TP.PaymentAmount)
WHEN TP.PaymentFrequencyId=2 THEN (DATEDIFF(WEEK, TP.StartDate, TP.EndDate)*(TP.PaymentAmount/2))
ELSE (DATEDIFF(MONTH, TP.StartDate, TP.EndDate)*TP.PaymentAmount)
END AS SumOfPayment

FROM Property P INNER JOIN OwnerProperty OP ON P.Id=OP.PropertyId
INNER JOIN TenantProperty TP ON TP.PropertyId = OP.PropertyId
INNER JOIN TenantPaymentFrequencies TPF ON TPF.Id = TP.PaymentFrequencyId

WHERE OP.OwnerId = 1426


--Display the yield.

SELECT P.Id AS [PropertyId], P.Name AS [PropertyName], OP.OwnerId, PF.Yield

FROM Property P INNER JOIN OwnerProperty OP ON P.Id = OP.PropertyId
INNER JOIN PropertyFinance PF ON OP.PropertyId = PF.PropertyId

WHERE OP.OwnerId = 1426