--Display a list of all property names and their property id�s for Owner Id: 1426. 

SELECT p.Name AS [Property Name], p.Id AS [PropertyId]
FROM [Keys].[dbo].[Property] p INNER JOIN [Keys].[dbo].[OwnerProperty] o ON p.Id=o.PropertyId
WHERE o.OwnerId=1426