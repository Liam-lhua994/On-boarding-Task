--Display all property names, current tenants first and last names and rental payments per week/ fortnight/month for the properties in question a). 

SELECT P.Id AS [PropertyId], P.Name AS [PropertyName], OP.OwnerId, Person.FirstName, 
	Person.LastName, TP.PaymentAmount, TPF.Name AS [PaymentFrequency]

FROM Property P INNER JOIN OwnerProperty OP ON P.Id = OP.PropertyId
INNER JOIN TenantProperty TP ON TP.PropertyId = OP.PropertyId
INNER JOIN TenantPaymentFrequencies TPF ON TPF.Id = TP.PaymentFrequencyId
INNER JOIN Person ON Person.Id=OP.OwnerId

WHERE OP.OwnerId = 1426