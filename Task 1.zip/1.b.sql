--Display the current home value for each property in question a). 

SELECT p.Name AS [Property Name], p.Id AS [PropertyId], ph.Value AS [Home Value]
FROM Property p INNER JOIN OwnerProperty o ON p.Id = o.PropertyId
INNER JOIN PropertyHomeValue ph ON o.PropertyId = ph.PropertyId
WHERE o.OwnerId = 1426