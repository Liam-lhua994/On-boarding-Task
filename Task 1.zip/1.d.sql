--Display all the jobs available

SELECT Job.JobDescription, JobStatus.Status AS [JobStatus]
FROM Job INNER JOIN JobStatus ON Job.JobStatusId = JobStatus.Id
WHERE JobStatus.Id=1